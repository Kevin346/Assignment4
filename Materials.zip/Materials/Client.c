//*******************************************************************************
// Name: Kevin Flores                                                           *
// Course: CS 3377.0w1                                                          *
// Date: 12/03/2018                                                             *
//*******************************************************************************

#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <arpa/inet.h>


#define MAXLINE 4096 /*max text line length*/
//#define SERV_PORT 10010 /*port*/

int main(int argc, char **argv) 
{
 
 int sockfd;
 FILE *logfd;
 struct sockaddr_in servaddr;
 char sendline[MAXLINE], recvline[MAXLINE];
 char prompt[] = "SimpleShell: Enter command or exit: ";


 //Earse log file
    printf("%s\n", argv[3]);
    logfd = fopen(argv[3], "w");   
    fprintf(logfd, "This is the log file for client.\n");	

 //basic check of the arguments
 //additional checks can be inserted
 if (argc !=4) {
  perror("Error: TCPClient <Server IP> <Server Port>");
  fprintf(logfd,"Error: TCPClient <Server IP> <Server Port>\n"); 
  exit(1);
 }


 //Create a socket for the client
 //If sockfd<0 there was an error in the creation of the socket
 if ((sockfd = socket (AF_INET, SOCK_STREAM, 0)) <0) {
  perror("Problem in creating the socket");
  fprintf(logfd,"Problem in creating the socket\n");
  exit(2);
 }
	
 //Creation of the socket
 memset(&servaddr, 0, sizeof(servaddr));
 servaddr.sin_family = AF_INET;
 servaddr.sin_addr.s_addr= inet_addr(argv[1]);
 servaddr.sin_port =  htons(atoi(argv[2])); 
 //servaddr.sin_port =  htons(SERV_PORT); //convert to big-endian order
	
 //Connection of the client to the socket 
 if (connect(sockfd, (struct sockaddr *) &servaddr, sizeof(servaddr))<0) {
  perror("Problem in connecting to the server");
  fprintf(logfd, "Problem in connecting to the server\n");
  exit(3);
 }

 printf("Connection Success \n");
 fprintf(logfd, "Connection Success \n");

 /*prompt displayed */
    printf("%s", prompt );
    fprintf(logfd, "SimpleShell: Enter command or exit: \n");

 while (fgets(sendline, MAXLINE, stdin) != NULL) 
 {
    fprintf(logfd,"%s",sendline);
    /* fgets leaves '\n' in input buffer. ditch it */
    sendline[strlen(sendline)-1] = '\0';

    //checks if user wants to exit
        if(strcmp(sendline,"exit") == 0)
            {
                fprintf(logfd, "exit\n");
                break;} 
        else 
        {//communicates the command to the server and then recievces the result and logs it
            //required promt
            system("hostname; date");
            send(sockfd, sendline, strlen(sendline), 0);
            if (recv(sockfd, recvline, MAXLINE,0) == 0){
            //error: server terminated prematurely
            perror("The server terminated prematurely");
            fprintf(logfd, "The server terminated prematurely"); 
            exit(4);
            }
            printf("%s", "String received from the server: ");
            fprintf(logfd,"String received from the server: ");
            fputs(recvline, stdout);
            fprintf(logfd, "%s",recvline);
            printf("\n");
            printf("Connection Success \n");
        }
 }

 fprintf(logfd, "End of log");
 exit(0);
}
